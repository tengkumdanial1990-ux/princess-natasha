Princess Natasha: Royal Money Adventure

Early browser-game prototype for itch.io.
Upload the ZIP to itch.io and enable the option that says the file will be played in the browser.
Suggested viewport: 720 x 1280 (portrait-friendly). Enable mobile scaling if offered.
Please test on phone and laptop before sharing widely.
